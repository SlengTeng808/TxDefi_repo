class WebMessage:
    def __init__(self):
        self.timestamp = ""
        self.appname = ""
        self.user = ""
        self.message = ""